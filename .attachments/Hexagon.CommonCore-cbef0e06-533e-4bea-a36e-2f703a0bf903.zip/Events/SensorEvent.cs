﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hexagon
{
    public class SensorEvent : DeviceEvent
    {
        public SensorEventEnum EventType { get; set; }
    }
}
