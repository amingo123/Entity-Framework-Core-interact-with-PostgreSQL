﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{

    public class DeviceEvent : HMI_Packet
    {
        public override HMI_MessageTypeEnum MessageType { get { return HMI_MessageTypeEnum.Event; } }

        public HMI_EventStatusEnum Status { get; set; }

        public Guid EventGuid { get; set; } = Guid.NewGuid();

        [MaxLength(256)]
        public string EventDescription { get; set; }

        public int DeviceTypeEventId { get; set; }

        [MaxLength(128)]
        public string FaultCause { get; set; }

        [MaxLength(256)]
        public string FaultSolution { get; set; }

        [JsonIgnore]
        public int FilterGroup { get; set; }

        [JsonIgnore]
        public long FilterTimeout { get; set; }

        public DateTime? Disabled { get; set; }

    }
}
