﻿namespace Hexagon
{
    public class MeasurementSWEvent : DeviceEvent
    {
        public MeasurementSWEventEnum EventType { get; set; }
        public string MachineComment { get; set; }

    }
}
