﻿namespace Hexagon
{
    public class CMMControllerEvent : DeviceEvent
    {
        public MachineEventEnum MachineEvent { get; set; }
        public string MachineError { get; set; }
    }
}
