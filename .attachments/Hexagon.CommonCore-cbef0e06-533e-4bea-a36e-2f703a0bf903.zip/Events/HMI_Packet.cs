﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hexagon
{
    public abstract class HMI_Packet
    {
        [Key, Column(Order = 0)]
        [MaxLength(256)]
        public string DeviceID { get; set; }

        [JsonProperty("IoTDeviceID")]
        public Guid AssetID { get; set; }

        public abstract HMI_MessageTypeEnum MessageType { get; }

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public DateTime LocalTimestamp => Timestamp.ToLocalTime();

        public DeviceClassEnum DeviceClass { get; set; }

        public DeviceTypeEnum DeviceType { get; set; }
    }
}
