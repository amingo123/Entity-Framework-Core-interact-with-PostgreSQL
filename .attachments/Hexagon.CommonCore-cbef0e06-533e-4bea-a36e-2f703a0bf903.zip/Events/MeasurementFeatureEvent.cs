﻿namespace Hexagon
{
    public class MeasurementFeatureEvent : DeviceEvent
    {
        //public double Measured { get; set; } // TODO Restore Metrology Data
        //public double PlusTol { get; set; } // TODO Restore Metrology Data
        //public double MinusTol { get; set; } // TODO Restore Metrology Data
        //public double Deviation { get; set; } // TODO Restore Metrology Data
        //public double OTol { get; set; }  // TODO Restore Metrology Data
        public double Bonus { get; set; }
        public bool IsOutOfTolerance { get; set; }

    }
}
