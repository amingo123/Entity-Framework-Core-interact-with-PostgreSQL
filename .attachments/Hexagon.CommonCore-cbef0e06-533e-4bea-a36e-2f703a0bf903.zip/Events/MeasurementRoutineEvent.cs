﻿namespace Hexagon
{
    public class MeasurementRoutineEvent : DeviceEvent
    {
        public MeasurementRoutineEventType EventType { get; set; }
        public string ProgramName { get; set; }
        public string ProgramFilePathName { get; set; }
        public string CommandGuid { get; set; }
        public string CommandId { get; set; }
    }
}
