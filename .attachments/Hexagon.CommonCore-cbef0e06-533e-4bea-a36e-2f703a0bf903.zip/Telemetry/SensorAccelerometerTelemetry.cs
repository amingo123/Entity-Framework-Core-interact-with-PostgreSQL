﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    [Table("SensorAccelerometerTelemetry")]
    public class SensorAccelerometerTelemetry : SensorTelemetry
    {
        public double ValueX { get; set; }
        public double ValueY { get; set; }
        public double ValueZ { get; set; }
    }
}
