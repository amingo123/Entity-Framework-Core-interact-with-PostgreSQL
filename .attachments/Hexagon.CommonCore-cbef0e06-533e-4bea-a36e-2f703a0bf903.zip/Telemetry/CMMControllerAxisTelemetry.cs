﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class CMMControllerAxisTelemetry : DeviceTelemetry
    {
        public int DistMov { get; set; }

        public double Temp { get; set; }

        public int StkUsgDistr0 { get; set; }
        public int StkUsgDistr1 { get; set; }
        public int StkUsgDistr2 { get; set; }
        public int StkUsgDistr3 { get; set; }
        public int StkUsgDistr4 { get; set; }
        public int StkUsgDistr5 { get; set; }
        public int StkUsgDistr6 { get; set; }
        public int StkUsgDistr7 { get; set; }
        public int StkUsgDistr8 { get; set; }
        public int StkUsgDistr9 { get; set; }
    }
}
