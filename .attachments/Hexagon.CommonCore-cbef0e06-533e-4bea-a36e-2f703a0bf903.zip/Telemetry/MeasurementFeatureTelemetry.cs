﻿namespace Hexagon
{
    public class MeasurementFeatureTelemetry : DeviceTelemetry
    {
        public double Measured { get; set; }
        public double PlusTol { get; set; }
        public double MinusTol { get; set; }
        public double Deviation { get; set; }
        public double OTol { get; set; } // TODO Name should change from O-Tol
        public double Bonus { get; set; }
        public bool IsOutOfTolerance { get; set; }
    }

}
