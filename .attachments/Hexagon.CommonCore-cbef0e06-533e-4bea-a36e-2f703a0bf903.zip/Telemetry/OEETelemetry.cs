﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class OEETelemetry : DeviceTelemetry
    {
        public double OEE { get; set; }
        public double Availability { get; set; }
        public double Performance { get; set; }
        public double Quality { get; set; }
        public double ScheduledTime { get; set; }
        public double OperatingTime { get; set; }
        public double TimeToExecutePart { get; set; }
        public double TimeCmmIdle { get; set; }
    }
}
