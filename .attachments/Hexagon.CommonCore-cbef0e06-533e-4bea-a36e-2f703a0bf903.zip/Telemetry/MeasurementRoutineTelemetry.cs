﻿using System;

namespace Hexagon
{
    public class MeasurementRoutineTelemetry : DeviceTelemetry
    {
        public bool FileSaved { get; set; }
        public bool FileState { get; set; }
        public MeasurementExecutionState ExecutionState { get; set; }
        public string ExecutionErrorMessage { get; set; }
        public string ExecutionStatusMessage { get; set; }
        public string ExecutionGuid { get; set; }
        public bool TempCompActive { get; set; }
        public MeasurementFileQuitCode FileQuitCode { get; set; }
        public bool PrintStart { get; set; }
        public bool PrintEnd { get; set; }
        public bool PrintStatus { get; set; }
        public bool PrintToExcel { get; set; }
        public string ExcelFilename { get; set; }
        public bool DmisOutput { get; set; }
        public string DmisOutputFile { get; set; }
        public string CurrentRunReportPath { get; set; }
        public string DefaultRunReportPath { get; set; }
        public string CurrentProbeName { get; set; }

        // Internally Calculated

        public DateTime? PartExecutionStartTime { get; set; }  // use DateTime.Now Not .UtcNow
        public DateTime? PartExecutionEndTime { get; set; }  // use DateTime.Now Not .UtcNow
        public DateTime? ExecutionErrorStartTime { get; set; }  // use DateTime.Now Not .UtcNow
        public DateTime? ExecutionErrorEndTime { get; set; }  // use DateTime.Now Not .UtcNow
        public int NumberOfFeaturesOutOfTolerance { get; set; }  // TODO calculated after measurement
        public int NumberOfFeaturesInTolerance { get; set; }  // TODO calculated after measurement
    }
}
