﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public sealed class HMISystemTelemetry : DeviceTelemetry
    {
        public HMI_StatusEnum CrashStatus { get; set; }
        // TODO: Restore logic for CrashValue as a string once CrashValue is changed to a string in Prod
        //[MaxLength(256)]
        //public string CrashValue { get; set; }
        public double CrashValue { get; set; }

        public HMI_StatusEnum VibrationStatus { get; set; }

        // TODO: Restore logic for VibrationValue as a string once VibrationValue is changed to a string in Prod
        //[MaxLength(256)]
        //public string VibrationValue { get; set; }
        public double VibrationValue { get; set; }

        public HMI_StatusEnum AirPressureStatus { get; set; }

        public double AirPressureValue { get; set; }

        public HMI_StatusEnum HumidityStatus { get; set; }

        public double HumidityValue { get; set; }

        public HMI_StatusEnum IlluminanceStatus { get; set; }

        public double IlluminanceValue { get; set; }

        public HMI_StatusEnum TemperatureStatus { get; set; }

        public double TemperatureValue { get; set; }
    }
}
