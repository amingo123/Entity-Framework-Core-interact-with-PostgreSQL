﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    [JsonConverter(typeof(TelemetryConverter))]
    public class DeviceTelemetry : HMI_Packet
    {
        public override HMI_MessageTypeEnum MessageType { get { return HMI_MessageTypeEnum.Telemetry; } }

        public HMI_StatusEnum Status { get; set; }

        [JsonIgnore]
        public HMI_TelemetryFilterType FilterType { get; set; }
    }
}
