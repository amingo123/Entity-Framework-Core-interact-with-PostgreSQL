﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class CMMControllerTelemetry : DeviceTelemetry
    {
        public int ControlBootEv { get; set; }
        public int MotorOnEv { get; set; }
        public int MotorOffEv { get; set; }
        public int StopButtonPressed { get; set; }
        public int SafetyBarrierEv { get; set; }
        public int ParamChangeEv { get; set; }
        public int CompMapChangeEv { get; set; }
        public int LowLevelMatrixChangeEv { get; set; }
        public int BaseCompActivationEv { get; set; }
        public int TermCompActivationEv { get; set; }
        public int EcoMode1Ev { get; set; }
        public int EcoMode2Ev { get; set; }
        public int EcoModeEndEv { get; set; }
        public int CompMapActivationEv { get; set; }
        public int TimeControllerOn { get; set; }
        public int HomingProcedure { get; set; }
        public int IndexWristRot { get; set; }
        public int RotTabRot { get; set; }
        public int NumAxesMov { get; set; }
        public int NumPrbChanges { get; set; }
        public int NumCncPrbPnts { get; set; }
        public int NumJogPrbPnts { get; set; }
        public int NumOpenLoop { get; set; }
        public int NumClosedLoop { get; set; }
        public int NumErrors { get; set; }
        public int DistMovRotTab { get; set; }
        public int DistMovContA { get; set; }
        public int DistMovContB { get; set; }
        public int DistMovRT2 { get; set; }
        public int DistMovZ2 { get; set; }
        public int DistMovYAW { get; set; }
        public double TempPart { get; set; }
        public int TimeEcoMode { get; set; }
        public int Feed { get; set; }
        public int CncTime { get; set; }
        public int JogTime { get; set; }
        public int TimeEcoModeDelta { get; set; }
        public int TimeControllerOnDelta { get; set; }
        public int CncTimeDelta { get; set; }
        public int JogTimeDelta { get; set; }
    }
}
