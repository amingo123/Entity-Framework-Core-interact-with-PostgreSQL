﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum SensorEventEnum
    {
        None,
        HighCritical,
        LowCritical,
        HighWarning,
        LowWarning,
        Swing1HrCritical,
        Swing24HrCritical,
        Disconnected
    }
}
