﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum HMI_EventStatusEnum
    {
        // Ordered based on severity so we can use an easy comparison
        Unknown,        
        Hidden,
        Info,
        Settings,
        Disconnected,
        Warning,
        Critical,
    }
}
