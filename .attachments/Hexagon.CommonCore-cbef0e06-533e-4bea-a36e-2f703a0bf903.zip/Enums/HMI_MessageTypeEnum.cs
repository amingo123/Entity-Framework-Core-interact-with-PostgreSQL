﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum HMI_MessageTypeEnum
    {
        Telemetry,
        Properties,
        Event,
    }

}
