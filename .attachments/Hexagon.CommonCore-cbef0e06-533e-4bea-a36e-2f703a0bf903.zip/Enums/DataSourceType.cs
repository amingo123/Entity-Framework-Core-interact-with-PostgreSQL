﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DataSourceType
    {
        None,
        SFService,
        PulseBLE,
        Hub,
        CMMAdapter,
        Pcdmis,
        PcdmisAutomation,
        QuindosLegacy,
        QuickConnect,
        RelayInterface,  // Special Case: RelayInterface will not affect properties.  It's for interfaces which are not "true" data sources
    }
}
