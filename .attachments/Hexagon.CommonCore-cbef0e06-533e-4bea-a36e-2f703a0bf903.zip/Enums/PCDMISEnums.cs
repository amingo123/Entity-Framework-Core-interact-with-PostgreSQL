﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum MachineEventEnum
    {
        Unknown,
        MachineConnected,
        MachineConnecting,
        MachineDisconnected,
        MachineError,
        MachineHomingStarted,
        MachineConnectionTimeout,
        SlaveConnected,
        SlaveDisconnected,
        JogProbePoint,
        IndexableWristRotated,
        RotaryTableRotated,
        ProbeChanged,
        LowLevelMatrixChanged,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum MeasurementSWEventEnum
    {
        Unknown,
        PartProgramOpened,
        PartProgramClosed,
        PartProgramCompleted,
        PartProgramContinued,
        PartProgramCanceled,
        PartProgramStarted,
        PartProgramStopped,
        CalibrationComplete,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum FileFormatEnum
    {
        Unknown,
        UTF8,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum FileMethodEnum
    {
        Unknown,
        UltraSecretMode,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum MeasurementRoutineEventType
    {
        Calibration,
        Dimension,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum MeasurementExecutionState
    {
        Canceled,
        Completed,
        Continued,
        Started,
        Stopped,
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum MeasurementFileQuitCode
    {
        Unknown,
        NotFileQuit,
        QuitByUser,
        QuitByBadArchive,
    }

}
