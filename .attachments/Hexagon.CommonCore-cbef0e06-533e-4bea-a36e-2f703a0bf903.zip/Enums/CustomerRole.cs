﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum CustomerRole
    {
        User,
        Administrator,
        HmiWebService
    }
}
