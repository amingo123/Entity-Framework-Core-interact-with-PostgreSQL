﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum HMI_TelemetryFilterType
    {
        // Status when no change is found
        // 
        NotModified,
        // Status when a small change is found that would normally be filtered
        Filtered,
        // Status when a significant data item changes... most typical case
        Modified,
    }
}
