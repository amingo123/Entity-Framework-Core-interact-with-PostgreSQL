﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DeviceClassEnum
    {
        Unknown,

        Sensor,

        [Display(Name = "Accelerometer")]
        SensorAccelerometer,

        [Display(Name = "Temperature")]
        SensorTemperature,

        Environmental,

        [Display(Name = "Measurement Software")]
        MeasurementSW,

        [Display(Name = "Measurement Feature")]
        MeasurementFeature,

        [Display(Name = "Measurement Routine")]
        MeasurementRoutine,

        [Display(Name = "System")]
        HMISystem,

        [Display(Name = "CMM Controller")]
        CMMController,

        [Display(Name = "CMM Controller Axis")]
        CMMControllerAxis,

        [Display(Name = "OEE")]
        OEE,

        [Display(Name = "Generic System")]
        GenericDevice,

        [Display(Name = "Root Device")]
        Root,
    }
}