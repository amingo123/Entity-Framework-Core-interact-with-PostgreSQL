﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DeviceTypeEnum
    {
        Unknown,
        Crash,
        Vibration,
        AirPressure,
        Humidity,
        Illuminance,
        Proximity,
        Switch,
        Temperature,
        PCDMIS,
        Quindos,
        SpacialAnalyzer,
        HUB,
        PulseBLE,
        CMMControllerGeneric,
        CMMControllerDC240,
        CMMControllerDC241,
        CMMControllerDC800,
        CMMControllerDCRC1,
        CMMControllerH3CT,
        CMMControllerFB2,
        CMMControllerB3C,
        CMMControllerB4,
        CMMControllerB5,
        CMMControllerUMP360,
        CMMControllerSMP400,
        CMMControllerAxis,
        CMMSystemGeneric,
        CMMSystemGlobal,
        CMMSystemGlobalS,
        CMMSystemTigoSF,
        CMMSystemSF454,
        CMMSystemSF7107,
        CMMSystemMicroHite,
        CMMSystemGlobal555,
        CMMSystemOptivReference663,
        CMMSystemLeitzReference,
        CMMSystemPMMC,
        CMMSystemOptiveReference2z543,
        CMMSystemHorizontalArm,
        CMMSystemDelta,
        ArmSystem,
        TrackerSystem,
        WLS400System,
        WLS400MountedSystem,
        OEE,
        Caliper,
        Probe,
        QuickConnect,
        Generic,
        MeasurementSWGeneric,
        MeasurementRoutineGeneric,
        MeasurementFeatureGeneric,
    }
}
