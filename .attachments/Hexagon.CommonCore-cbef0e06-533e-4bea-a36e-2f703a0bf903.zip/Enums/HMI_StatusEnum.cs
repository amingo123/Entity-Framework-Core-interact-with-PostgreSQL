﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum HMI_StatusEnum
    {
        Unknown,
        Idle,
        IdleWarning,
        IdleCritical,
        Running,
        RunningWarning,
        RunningCritical,
        Waiting,
        WaitingWarning,
        WaitingCritical,
        Creating,
        CreatingWarning,
        CreatingCritical,
        LostConnection,
    }
}