﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum HMI_DeviceUnits
    {
        Unknown,
        NotApplicable,
        Celsius,
        Farenheit,
        PSI,
        Bars,
        MPascal, //μPa
        AccelLMH,
        Centimeters,
        Millimeters,
        MillimetersPerSecond,
        Lumens,
        Percent,
    }
}
