﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hexagon
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum SensorParentTypeEnum
    {
        Unknown,
        Pulse,
        CMM
    }
}
