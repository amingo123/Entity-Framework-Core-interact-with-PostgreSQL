﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class EnvironmentalProperties : DeviceProperties
    {
        [MaxLength(64)]
        public string FirmwareVersion { get; set; }

        public string SerialNumber { get; set; }

        public string UID { get; set; }
    }
}
