﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hexagon
{
    public class MeasurementRoutineProperties : DeviceProperties
    {
        public string ProgramName { get; set; }
        public string ProgramFilePathName { get; set; }
        public string RoutineGuid { get; set; }
        public string PartGuid { get; set; }
        public FileFormatEnum FileFormat { get; set; } 
        public FileMethodEnum FileMethod { get; set; }
        public TimeSpan? IdealTime { get; set; }
    }

}
