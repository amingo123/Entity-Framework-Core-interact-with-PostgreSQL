﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hexagon
{
    [JsonConverter(typeof(PropertiesConverter))]
    public class DeviceProperties : HMI_Packet
    {
        public override HMI_MessageTypeEnum MessageType { get { return HMI_MessageTypeEnum.Properties; } }

        [MaxLength(256)]
        public string LongName { get; set; }

        [MaxLength(64)]
        public string ShortName { get; set; }

        [MaxLength(256)]
        public string Description { get; set; }

        public int ChildID { get; set; }

        [MaxLength(256)]
        public string ParentDeviceID { get; set; }

        public DeviceClassEnum ParentDeviceClass { get; set; }

        public DeviceTypeEnum ParentDeviceType { get; set; }

        public DateTime? Disabled { get; set; }

        public DataSourceType PropertiesSource { get; set; }
        public DataSourceType TelemetrySource { get; set; }
        public DataSourceType EventSource { get; set; }
    }
}