﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hexagon
{
    public class SensorProperties : DeviceProperties
    {
        public double CriticalHigh { get; set; } = double.MaxValue;
        public double WarningHigh { get; set; } = double.MaxValue;
        public double WarningLow { get; set; } = -99999;
        public double CriticalLow { get; set; } = -99999;
        public long RefreshMin { get; set; }
        public long RefreshMax { get; set; }
        public long RefreshRate { get; set; }
        public double ValueChangedTolerance { get; set; }
        public double SensorMaximumValue { get; set; }
        public double SensorMinimumValue { get; set; }
        public HMI_DeviceUnits Units { get; set; }
        public SensorParentTypeEnum SensorParentType { get; set; }
    }
}