﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class CMMControllerProperties : DeviceProperties
    {
        public int Version { get; set; }

        [MaxLength(256)]
        public string MAC { get; set; }

        [MaxLength(256)]
        public string ControllerType { get; set; }

        [MaxLength(256)]
        public string FDCVersion { get; set; }

        [MaxLength(256)]
        public string SerialNumber { get; set; }

        public int MachineID { get; set; }
        public int WristPresent { get; set; }
        public int RTPresent { get; set; }
        public int Z2AxisPresent { get; set; }
    }
}
