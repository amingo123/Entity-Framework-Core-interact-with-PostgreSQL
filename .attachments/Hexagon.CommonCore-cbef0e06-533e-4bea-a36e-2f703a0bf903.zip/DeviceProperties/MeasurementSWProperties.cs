﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class MeasurementSWProperties : DeviceProperties
    {
        [MaxLength(64)]
        public string SWVersionName { get; set; }
        public DateTime? LockExpiration { get; set; }

    }

}
