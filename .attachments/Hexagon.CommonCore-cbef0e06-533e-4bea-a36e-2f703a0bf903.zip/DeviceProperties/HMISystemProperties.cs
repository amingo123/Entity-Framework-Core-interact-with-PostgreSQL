﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class HMISystemProperties : DeviceProperties
    {
        [Required]
        [MaxLength(256)]
        public string SerialNumber { get; set; }

        [Required]
        [MaxLength(256)]
        public string MachineType { get; set; }

        [Required]
        [MaxLength(256)]
        public string MachineDefaults { get; set; }

        [MaxLength(256)]
        public string MachineLocation { get; set; }

        [MaxLength(256)]
        public string MetrologySoftware { get; set; }

        [MaxLength(256)]
        public string MetrologySoftwareVersion { get; set; }

        public DateTime? LastServiceDate { get; set; }

        public DateTime? InstallationDate { get; set; }

        public DateTime? CalibrationDate { get; set; }

        public string ComputerName { get; set; }

        public HMI_DeviceUnits CrashUnits { get; set; } = HMI_DeviceUnits.AccelLMH;
        public HMI_DeviceUnits VibrationUnits { get; set; } = HMI_DeviceUnits.AccelLMH;
        public HMI_DeviceUnits AirPressureUnits { get; set; } = HMI_DeviceUnits.Bars;
        public HMI_DeviceUnits HumidityUnits { get; set; } = HMI_DeviceUnits.Percent;
        public HMI_DeviceUnits IlluminanceUnits { get; set; } = HMI_DeviceUnits.Lumens;
        public HMI_DeviceUnits TemperatureUnits { get; set; } = HMI_DeviceUnits.Celsius;
    }
}
