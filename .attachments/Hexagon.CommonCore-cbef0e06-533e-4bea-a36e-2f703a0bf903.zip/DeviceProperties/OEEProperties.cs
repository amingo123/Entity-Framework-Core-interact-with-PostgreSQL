﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexagon
{
    public class OEEProperties : DeviceProperties
    {
        public double HoursSunday { get; set; }
        public double HoursMonday { get; set; }
        public double HoursTuesday { get; set; }
        public double HoursWednesday { get; set; }
        public double HoursThursday { get; set; }
        public double HoursFriday { get; set; }
        public double HoursSaturday { get; set; }
        public double WarningOEE { get; set; } = 0;
        public double CriticalOEE { get; set; } = 0;

    }
}
