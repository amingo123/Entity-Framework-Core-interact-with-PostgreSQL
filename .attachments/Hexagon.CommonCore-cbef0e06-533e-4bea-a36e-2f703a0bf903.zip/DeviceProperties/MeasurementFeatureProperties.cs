﻿namespace Hexagon
{
    public class MeasurementFeatureProperties : DeviceProperties
    {
        public string CommandGuid { get; set; }
        public string CommandId { get; set; } // human readable... probably should move to short/long name.
        //public double Nominal { get; set; } // TODO Restore Metrology Data

    }

}
